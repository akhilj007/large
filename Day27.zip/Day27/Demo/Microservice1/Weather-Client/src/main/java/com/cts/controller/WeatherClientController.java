package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cts.dto.Weather;

@RestController
@RequestMapping("/api/v1/client")
public class WeatherClientController {
	
	@Autowired
	public RestTemplate restTemplate;

	@GetMapping("/test")
	public String getWeatherForcast() {
		return "Rain is likely....";
	}
	
	@GetMapping("/todaybyclient")
	public Weather getWeather() {
		
		Weather weather = null;
		
		//String url = "http://localhost:8090/api/v1/weather/today";
		String url = "http://10.232.61.84:8090/api/v1/weather/today";
		
		try {
			weather = restTemplate.getForObject(url,Weather.class);
		}catch(Exception ex) {
			ex.getStackTrace();
		}
		return weather;
	}
}
