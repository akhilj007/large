package com.cts.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Weather;

@RestController

@RequestMapping("/api/v1/weather")
public class WeatherController {

	@GetMapping("/today")
	public Weather getWeather() {
		Weather weather = new Weather();
		weather.setHumidity(12.23);
		weather.setTemp(23.89);
		weather.setWindspeed(34.97);
		return weather;
	}
}
