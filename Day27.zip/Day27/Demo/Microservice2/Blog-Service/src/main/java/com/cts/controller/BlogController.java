package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClient;

import com.cts.dto.User;

@RestController
@RequestMapping("/api/v1/blogs")
public class BlogController {
	
	private final RestClient restClient;
	
	@Autowired
	public BlogController(RestClient.Builder restClientBuilder) {
		// Build the RestClient with a base URL
        this.restClient = restClientBuilder
                .baseUrl("http://localhost:8090/api/v1")
                .build();
	}

	@GetMapping()
	public ResponseEntity<?> getMessage(){
		return new ResponseEntity<>("Hi this is normal message from Unrestricted uri...",
				HttpStatus.OK);
	}
	
	@GetMapping("/callOtherApi/{id}")
	public User getUserFromUserService(@PathVariable Long id){
		return restClient.get()
                .uri("/users/{id}",id) // Define the URI with a path variable
                .retrieve()
                .body(User.class); // Specify the expected response type
	}
}
