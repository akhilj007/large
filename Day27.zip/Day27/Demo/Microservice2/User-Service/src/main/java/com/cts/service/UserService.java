package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.UserRepository;
import com.cts.model.User;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;
	
	public List<User> getAllUsers() {
		return userRepository.findAll();
	}
	
	public User getUserById(Long id) {
		Optional<User> user = userRepository.findById(id);
		User findUser = null;
		if(user.isPresent()) {
			findUser =  user.get();
		}
		return findUser;
	}
	
	public User createUser(User user) {
		return userRepository.save(user);
	}
	
	public User updateUser(Long id,User user) {
		User userUpdate = getUserById(id);
		User u = null;
		if(userUpdate!= null) {
			u = userRepository.save(user);
		}
		return u;
	}
	
	public void deleteUser(Long id) {
		User userDelete = getUserById(id);
		userRepository.delete(userDelete);
	}
}
